HTML is located in src->main->resources->templates

CSS is located in src->main->resources->static->css->style.css

Validation behaviour is located in

Client side is located in main->java

Database writes is located in main->java->uk->ac->city->sbbc662->coursework->entities

Database reads is located in main->java->uk->ac->city->sbbc662->coursework->dao

Security is located in tis-brownies.iks and main->java->uk->ac->city->sbbc662->coursework->config->SecurityConfig.java


Source: Session 8 example